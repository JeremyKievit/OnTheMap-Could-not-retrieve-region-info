//
//  FindLocationVC.swift
//  OnTheMap
//
//  Created by admin on 11/9/20.
//  Copyright © 2020 Com.JeremyKievit. All rights reserved.
//

import Foundation
import UIKit
import MapKit

class FindLocationVC: UIViewController {
    
    @IBOutlet weak var locationField: UITextField!
    @IBOutlet weak var linkField: UITextField!
    
    @IBAction func cancelPin(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func findLocation(_ sender: Any) {
        if self.locationField == nil {
            DispatchQueue.main.async {
                let alert = UIAlertController(title: "Error", message: "Please provide a location", preferredStyle: UIAlertController.Style.alert)
                alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: { (action) in
                 alert.dismiss(animated: true, completion: nil)
                }))
                self.present(alert, animated: true, completion: nil)
            }
        } else if self.linkField == nil {
            DispatchQueue.main.async {
                let alert = UIAlertController(title: "Error", message: "Please include your Linkedin profile to proceed", preferredStyle: UIAlertController.Style.alert)
                alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: { (action) in
                 alert.dismiss(animated: true, completion: nil)}))
                self.performSegue(withIdentifier: "PostLocation", sender: self)
            }
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let controller = segue.destination as! PostLocationVC
        
        controller.locationResponse = locationField.text
        controller.linkResponse = linkField.text
                
    }
}

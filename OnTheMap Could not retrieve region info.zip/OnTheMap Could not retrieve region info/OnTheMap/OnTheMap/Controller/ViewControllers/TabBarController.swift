//
//  TabBarController.swift
//  OnTheMap
//
//  Created by admin on 11/20/20.
//  Copyright © 2020 Com.JeremyKievit. All rights reserved.
//

import Foundation
import UIKit

class TabBarController: UITabBarController {
    @IBAction func logout(_ sender: Any) {
        OTMClient.logout(completion: handleLogoutResponse(success:error:))
    }
    
    func handleLogoutResponse(success: Bool, error: Error?) {
        if success {
            print("logged out")
            
        } else {
            //Call logout error alert
            DispatchQueue.main.async {
                let alert = UIAlertController(title: "Error", message: "Log out failed", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "OK", style: .cancel, handler: nil))
                self.present(alert, animated: true, completion: nil)
            }
        }
    }
}

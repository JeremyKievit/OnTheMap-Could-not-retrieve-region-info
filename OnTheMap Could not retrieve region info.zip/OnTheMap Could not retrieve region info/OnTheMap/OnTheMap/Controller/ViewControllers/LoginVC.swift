//
//  LoginVC.swift
//  OnTheMap
//
//  Created by admin on 11/9/20.
//  Copyright © 2020 Com.JeremyKievit. All rights reserved.
//

import Foundation
import UIKit

class LoginVC: UIViewController {
    
    @IBOutlet weak var emailField: UITextField!
    @IBOutlet weak var passwordField: UITextField!
    
    override func viewWillAppear(_ animated: Bool) {
        passwordField.isSecureTextEntry = true
    }
    
    override func viewDidLoad() {
        emailField.delegate = self
        passwordField.delegate = self
    }
    
    @IBAction func loginButton(_ sender: Any) {
        OTMClient.login(username: self.emailField.text!, password: self.passwordField.text!, completion: handleLoginResponse(success:error:))
    }
    @IBAction func signUpButton(_ sender: Any) {
    }
    
    func handleLoginResponse(success: Bool, error: Error?) {
        if success {
            OTMClient.getPublicUserData(userId: Data.Auth.userId, completion: handlePublicUserDataResponse(data:error:))
            DispatchQueue.main.async {
                self.performSegue(withIdentifier: "completeLogin", sender: nil)
            }
        } else {
            DispatchQueue.main.async {
                let alert = UIAlertController(title: "Login Error", message: error as? String, preferredStyle: UIAlertController.Style.alert)
                alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: { (action) in
                    alert.dismiss(animated: true, completion: nil)
                }))
                self.present(alert, animated: true, completion: nil)
            }
        }
    }
    
    func handlePublicUserDataResponse(data: UserData?, error: Error?) {
        guard let data = data else {
            DispatchQueue.main.async {
                let alert = UIAlertController(title: "Could not access user data", message: error as? String, preferredStyle: UIAlertController.Style.alert)
                alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: { (action) in
                    alert.dismiss(animated: true, completion: nil)
                }))
                self.present(alert, animated: true, completion: nil)
            }
            return
        }
            
        Data.User.firstName = data.firstName
        Data.User.lastName = data.lastName
    }
}

extension LoginVC: UITextFieldDelegate {
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
}

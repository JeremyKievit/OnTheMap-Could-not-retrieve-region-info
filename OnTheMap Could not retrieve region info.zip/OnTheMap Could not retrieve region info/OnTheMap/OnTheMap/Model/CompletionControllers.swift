//
//  CompletionControllers.swift
//  OnTheMap
//
//  Created by admin on 11/17/20.
//  Copyright © 2020 Com.JeremyKievit. All rights reserved.
//

import Foundation

struct CompletionControllers {
    let studentMapVC: String
    let studentTableVC: String
}

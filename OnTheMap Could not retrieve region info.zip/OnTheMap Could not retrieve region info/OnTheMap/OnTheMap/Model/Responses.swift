//
//  RequestStudentLocation.swift
//  OnTheMap
//
//  Created by admin on 11/14/20.
//  Copyright © 2020 Com.JeremyKievit. All rights reserved.
//
import MapKit

//MARK: session response
struct LoginResponse: Decodable {
    let account: Account
    let session: Session
}

struct Account: Decodable {
    let registered: Bool
    let key: String
}

struct Session: Decodable {
    let id: String
    let expiration: String
}

//MARK: getPublicUserData() response
struct UserData: Decodable {
    let firstName: String
    let lastName: String
    let key: String
    
    enum CodingKeys: String, CodingKey {
        case firstName = "first_name"
        case lastName = "last_name"
        case key
    }
}

//MARK: createStudentLocation() response
struct CreateLocationResponse: Decodable {
    let createdAt: String
    let objectId: String
}

//MARK: updateStudentLocation() response
struct UpdateStudentLocationResponse: Decodable {
    let updatedAt: String
}



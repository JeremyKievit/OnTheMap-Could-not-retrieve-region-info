//
//  MKPointAnotations.swift
//  OnTheMap
//
//  Created by admin on 11/17/20.
//  Copyright © 2020 Com.JeremyKievit. All rights reserved.
//

import Foundation

struct PinData: Codable {
    var createdAt: String?
    var firstName: String?
    var lastName: String?
    var latitude: Double?
    var longitude: Double?
    var mapString: String?
    var mediaURL: String?
    var objectId: String?
    var uniqueKey: String?
    var updatedAt: String?
}

